#include <iostream>
using namespace std;
int main()
{
	
	system("PAUSE");
	return 0;
}